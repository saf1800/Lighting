-- INSTRUCTIONS --

To get started look under the "Models" folder. Here you will see a subfolder for both the Standard and Mobile versions of the assets.

All models - both Standard and Mobile - use the textures found in the "Textures" folder.

-- GUIDELINES --

If you are unsure about how you are allowed to use the assets please see the Usage Guidelines: http://devassets.com/guidelines/

-- MADE BY --

This pack was created by BitGem and downloaded from http://devassets.com/.

-- HAVE FUN --

We hope you will enjoy the contents of the pack!